#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "tp_head_tools.h"

#include "ng_video_diag.h"





void chck_tp_diag_t_size(void)
{
    printf("tp_header_t:    %ld\n", sizeof(tp_header_t));
    printf("af_header_t:    %ld\n", sizeof(af_header_t));
    printf("tp_info_t:      %ld\n", sizeof(tp_info_t));
    printf("pcr_info_t:     %ld\n", sizeof(pcr_info_t));
    printf("jib_command_t:  %ld\n", sizeof(jib_command_t));

    printf("tp_diag_t:      %ld\n", sizeof(tp_diag_t));
}




// ###############################################################
// ###############################################################
//
//
//

void tp_fill_time (uint32_t *src_p, uint32_t *time_p)
{
    *((uint32_t *) time_p) = ntohl(*src_p);
}


// ###############################################################
// ###############################################################
//
//
//

void tp_fill_tp_head_t (uint32_t *src_p, tp_header_t *tp_header_p)
{
    *((uint32_t *) tp_header_p) = ntohl(*src_p);
}

void tp_hex_dump_tp_head_t (tp_header_t *tp_header_p)
{
    printf("  Hd       - 0x%08x\n", *((uint32_t *) tp_header_p));
}



// ###############################################################
// ###############################################################
//
//
//

void tp_fill_af_head_t (uint32_t *src_p, af_header_t *af_header_p)
{
    uint32_t  data_4b;

    // ----- Word 1 -----
    data_4b = ntohl(src_p[0]);

    // len
    af_header_p->len = (data_4b >> 24) & 0xFF;

    // flag
    af_header_p->discontinuity = (data_4b >> 23) & 0x1;
    af_header_p->random_access = (data_4b >> 22) & 0x1;
    af_header_p->es_priority   = (data_4b >> 21) & 0x1;
    af_header_p->pcr_flag      = (data_4b >> 20) & 0x1;
    af_header_p->opcr_flag     = (data_4b >> 19) & 0x1;
    af_header_p->splice_point  = (data_4b >> 18) & 0x1;
    af_header_p->private_data  = (data_4b >> 17) & 0x1;
    af_header_p->af_ext        = (data_4b >> 16) & 0x1;

    // pcr_base_1
    af_header_p->pcr_base_1    = (data_4b >>  0) & 0xFFFF;

    // ----- Word 1 -----
    data_4b = ntohl(src_p[1]);

    // pcr_base_2
    af_header_p->pcr_base_2    = (data_4b >> 16) & 0xFFFF;

    // pcr_base_3
    af_header_p->pcr_base_3    = (data_4b >> 15) & 0x1;

    // pcr_ext
    af_header_p->resv          = (data_4b >>  9) & 0x3F;
    af_header_p->pcr_ext       = (data_4b >>  0) & 0x1FF;
}

void tp_hex_dump_af_head_t (af_header_t *af_header_p)
{
    uint32_t  data_4b;

    printf("  AF       - ");

    // ----- Word 1 -----
    data_4b  = 0;
    // len
    data_4b |= (af_header_p->len & 0xFF)  << 24;
    // Flag
    data_4b |= ((af_header_p->discontinuity << 7) |
                (af_header_p->random_access << 6) |
                (af_header_p->es_priority   << 5) |
                (af_header_p->pcr_flag      << 4) |
                (af_header_p->opcr_flag     << 3) |
                (af_header_p->splice_point  << 2) |
                (af_header_p->private_data  << 1) |
                (af_header_p->af_ext        << 0)) << 16;
    // pcr_base_1
    data_4b |= (af_header_p->pcr_base_1 & 0xFFFF);
    printf("0x%08x ", data_4b);

    // ----- Word 2 -----
    data_4b  = 0;
    data_4b |=   (af_header_p->pcr_base_2 & 0xFFFF) << 16;
    data_4b |= (((af_header_p->pcr_base_3 & 0x0001) << 15) |
                ((af_header_p->resv       &   0x3F) <<  9) |
                ((af_header_p->pcr_ext    & 0x01FF) <<  0));
    printf("0x%08x ", data_4b);

    printf("\n");
}

void tp_dump_af_head_t (af_header_t *af_header_p)
{
    // len
    printf("  AF - len:       %d\n", af_header_p->len);

    // flag
    printf("  AF - flag:      %d%d%d%d%d%d%d%d\n",
           af_header_p->discontinuity,
           af_header_p->random_access,
           af_header_p->es_priority  ,
           af_header_p->pcr_flag     ,
           af_header_p->opcr_flag    ,
           af_header_p->splice_point ,
           af_header_p->private_data ,
           af_header_p->af_ext       );

    // pcr_base
    printf("  AF - pcr_base:  0x%04x%04x : %1d\n",
           af_header_p->pcr_base_1, af_header_p->pcr_base_2, af_header_p->pcr_base_3);

    // pcr_ext
    printf("  AF - pcr_ext:   0x%x\n", af_header_p->pcr_ext);

    printf("\n");
}



// ###############################################################
// ###############################################################
//
//
//

void tp_convrt_tp_info_t(uint32_t *data_p, tp_info_t *tp_info_p)
{
    uint32_t  data_4b;

    // Word 1
    data_4b = ntohl(data_p[0]);
    tp_info_p->info_type   = (data_4b >> 30) & 0x3;
    tp_info_p->pcr_flag    = (data_4b >> 29) & 0x1;
    tp_info_p->disc_flag   = (data_4b >> 28) & 0x1;
    tp_info_p->pat_flag    = (data_4b >> 27) & 0x1;
    tp_info_p->pmt_flag    = (data_4b >> 26) & 0x1;
    tp_info_p->idle_flag   = (data_4b >> 25) & 0x1;
    tp_info_p->unused_flag = (data_4b >> 24) & 0x1;
    tp_info_p->usage_id    = (data_4b >> 20) & 0xF;
    tp_info_p->arvl_time   = (data_4b >>  0) & 0xFFFFF;

    // World 2
    data_4b = ntohl(data_p[1]);
    tp_info_p->tp_idx    = (data_4b >> 16) & 0xFFFF;
    tp_info_p->pid_idx   = (data_4b >>  0) & 0xFFFF;

    // World 3 and 4
    // well, we ignore TP physical address here

    // World 3
    tp_info_p->addr      = ((((uintptr_t) ntohl(data_p[2])) << 32) |
                            (((uintptr_t) ntohl(data_p[3])) <<  0));
}

void tp_hex_dump_tp_info_t(tp_info_t *tp_info_p)
{
    uint32_t  data_4b;

    printf("  TP_Info  - ");

    // ----- Word 1 -----
    data_4b = (((tp_info_p->info_type   &     0x3) << 30) |
               ((tp_info_p->pcr_flag    &     0x1) << 29) |
               ((tp_info_p->disc_flag   &     0x1) << 28) |
               ((tp_info_p->pat_flag    &     0x1) << 27) |
               ((tp_info_p->pmt_flag    &     0x1) << 26) |
               ((tp_info_p->idle_flag   &     0x1) << 25) |
               ((tp_info_p->unused_flag &     0x1) << 24) |
               ((tp_info_p->usage_id    &     0xF) << 20) |
               ((tp_info_p->arvl_time   & 0xFFFFF) <<  0));
    printf("0x%08x ", data_4b);

    // ----- Word 2 -----
    data_4b = (((tp_info_p->tp_idx    &  0xFFFF) << 16) |
               ((tp_info_p->pid_idx   &  0xFFFF) <<  0));
    printf("0x%08x ", data_4b);

    // ----- Word 3 -----
    data_4b = (uint32_t) (tp_info_p->addr >> 32);
    printf("0x%08x ", data_4b);

    // ----- Word 3 -----
    data_4b = (uint32_t) (tp_info_p->addr >>  0);
    printf("0x%08x ", data_4b);

    printf("\n");
}



// ###############################################################
// ###############################################################
//
//
//

void tp_convert_pcr_info_t(uint32_t *data_p, pcr_info_t *pcr_info_p)
{
    uint32_t  data_4b;

    // Word 1
    data_4b = ntohl(data_p[0]);
    pcr_info_p->info_type   = (data_4b >> 30) & 0x3;
    pcr_info_p->out_time    = (data_4b >> 10) & 0xFFFFF;
    pcr_info_p->tbo_ext     = (data_4b >>  0) & 0x3FF;

    // Word 2
    data_4b = ntohl(data_p[1]);
    pcr_info_p->tbo_base    =  data_4b;

    // Word 3
    data_4b = ntohl(data_p[2]);
    pcr_info_p->valid_flag  = (data_4b >> 31) & 0x1;
    pcr_info_p->tp_itvl     = (data_4b >>  0) & 0x7FFFFFFF;
}

void tp_hex_dump_pcr_info_t(pcr_info_t *pcr_info_p)
{
    uint32_t  data_4b;

    printf("  PCR_Info - ");

    // ----- Word 1 -----
    data_4b = (((pcr_info_p->info_type  &     0x3) << 30) |
               ((pcr_info_p->out_time   & 0xFFFFF) << 10) |
               ((pcr_info_p->tbo_ext    &   0x3FF) <<  0));
    printf("0x%08x ", data_4b);

    // ----- Word 2 -----
    printf("0x%08x ", pcr_info_p->tbo_base);

    // ----- Word 3 -----
    data_4b = (((pcr_info_p->valid_flag &        0x1) << 31) |
               ((pcr_info_p->tp_itvl    & 0x7FFFFFFF) <<  0));
    printf("0x%08x ", data_4b);

    printf("\n");
}



// ###############################################################
// ###############################################################
//
//
//

void tp_convert_jib_command_t(uint32_t *data_p, jib_command_t *jib_cmd_p)
{
    uint32_t  data_4b;

    // Word 1
    data_4b = ntohl(data_p[0]);
    jib_cmd_p->qam_id     = (data_4b >> 21) & 0x7FF;
    jib_cmd_p->res1       = (data_4b >> 12) & 0x1FF;
    jib_cmd_p->pkt_type   = (data_4b >>  7) & 0x1F;
    jib_cmd_p->res2       = (data_4b >>  4) & 0x7;
    jib_cmd_p->cwi_hi     = (data_4b >>  0) & 0xF;

    // Word 2
    data_4b = ntohl(data_p[1]);
    jib_cmd_p->cwi_lo     = (data_4b >> 20) & 0xFFF;
    jib_cmd_p->out_time   = (data_4b >>  0) & 0xFFFFF;

    // Word 3
    data_4b = ntohl(data_p[2]);
    jib_cmd_p->pid_restamp_flag = (data_4b >> 31) & 0x1;
    jib_cmd_p->cc_restamp_flag  = (data_4b >> 30) & 0x1;
    jib_cmd_p->pcr_restamp_flag = (data_4b >> 29) & 0x1;
    jib_cmd_p->disc_flag        = (data_4b >> 28) & 0x1;
    jib_cmd_p->cc               = (data_4b >> 23) & 0xF;
    jib_cmd_p->pid              = (data_4b >> 10) & 0x1FFF;
    jib_cmd_p->tbo_ext          = (data_4b >>  0) & 0x3FF;

    // Word 4
    data_4b = ntohl(data_p[3]);
    jib_cmd_p->tbo_base         = data_4b;
}


void tp_hex_dump_jib_command_t(jib_command_t *jib_cmd_p)
{
    uint32_t  data_4b;

    printf("  JIM_cmnd - ");

    // ----- Word 1 -----
    data_4b = (((jib_cmd_p->qam_id     &   0x7FF) << 21) | 
               ((jib_cmd_p->res1       &   0x1FF) << 12) |
               ((jib_cmd_p->pkt_type   &    0x1F) <<  7) |
               ((jib_cmd_p->res2       &     0x7) <<  4) |
               ((jib_cmd_p->cwi_hi     &     0xF) <<  0));
    printf("0x%08x ", data_4b);

    // ----- Word 2 -----
    data_4b = (((jib_cmd_p->cwi_lo     &   0xFFF) << 20) |
               ((jib_cmd_p->out_time   & 0xFFFFF) <<  0));
    printf("0x%08x ", data_4b);

    // ----- Word 3 -----
    data_4b = (((jib_cmd_p->pid_restamp_flag &    0x1) << 31) |
               ((jib_cmd_p->cc_restamp_flag  &    0x1) << 30) |
               ((jib_cmd_p->pcr_restamp_flag &    0x1) << 29) |
               ((jib_cmd_p->disc_flag        &    0x1) << 28) |
               ((jib_cmd_p->cc               &    0xF) << 23) |
               ((jib_cmd_p->pid              & 0x1FFF) << 10) |
               ((jib_cmd_p->tbo_ext          &  0x3FF) <<  0)); 
    printf("0x%08x ", data_4b);

    // ----- Word 4 -----
    printf("0x%08x ", jib_cmd_p->tbo_base);

    printf("\n");
}

void tp_hex_dump_jib_command_t_tbo(jib_command_t *jib_cmd_p)
{
    printf("0x%08x, 0x%x, ", jib_cmd_p->tbo_base, jib_cmd_p->tbo_ext);
}

void tp_dec_dump_jib_command_t_tbo(jib_command_t *jib_cmd_p)
{
    uint64_t  tbo_27m;

    tbo_27m = jib_cmd_p->tbo_base * 600 + jib_cmd_p->tbo_ext;

    printf("%llu ", tbo_27m);
}

void tp_dec_dump_jib_command_t_out_time(jib_command_t *jib_cmd_p)
{
    
}


// ###############################################################
// ###############################################################
//
//
//

void tp_hex_dum_misc(tp_diag_t *tp_diag_p)
{
    uint32_t  data_4b;

    printf("  Misc     - ");

    data_4b = (((tp_diag_p->flow_id     &  0xFFFF) << 16) |
               ((tp_diag_p->flow_tp_idx &  0xFFFF) <<  0));
    printf("0x%08x ", data_4b);
    printf("0x%08x ", tp_diag_p->vir_addr);
    printf("\n");

    printf("  Magic    - ");
    printf("0x%08x ", tp_diag_p->magic);

    printf("\n");
}



// ###############################################################
// ###############################################################
//
//
//

void tp_hex_dump_tp_diag(tp_diag_t *tp_diag_p)
{
    printf("TP Diag Info:\n");

    // tp_hdr
    tp_hex_dump_tp_head_t(&tp_diag_p->tp_hdr);

    // af_hdr
    tp_hex_dump_af_head_t(&tp_diag_p->af_hdr);

    // orig_tp_hdr
    tp_hex_dump_tp_head_t(&tp_diag_p->orig_tp_hdr);

    // orig_af_hdr
    tp_hex_dump_af_head_t(&tp_diag_p->orig_af_hdr);

    // TP info
    tp_hex_dump_tp_info_t(&tp_diag_p->tp_info);

    // pcr_info
    tp_hex_dump_pcr_info_t(&tp_diag_p->pcr_info);

    // jib_command_t
    tp_hex_dump_jib_command_t(&tp_diag_p->jib_cmd);

    tp_hex_dum_misc(tp_diag_p);
}

void tp_2_tp_diag(uint32_t *tp_p, tp_diag_t *tp_diag_p)
{
    uint32_t  data_4b;

    // tp_hdr
    tp_fill_tp_head_t(&tp_p[0], &tp_diag_p->tp_hdr);

    // af_hdr
    tp_fill_af_head_t(&tp_p[1], &tp_diag_p->af_hdr);

    // time
    tp_fill_time (&tp_p[29], &tp_diag_p->time);

    // orig_tp_hdr
    tp_fill_tp_head_t(&tp_p[30], &tp_diag_p->orig_tp_hdr);

    // orig_af_hdr
    tp_fill_af_head_t(&tp_p[31], &tp_diag_p->orig_af_hdr);

    // TP info
    tp_convrt_tp_info_t(&tp_p[33], &tp_diag_p->tp_info);

    // pcr_info
    tp_convert_pcr_info_t(&tp_p[37], &tp_diag_p->pcr_info);

    // jib_command_t
    tp_convert_jib_command_t(&tp_p[40], &tp_diag_p->jib_cmd);

    // flow_id + flow_tp_idx
    data_4b = ntohl(tp_p[44]);
    tp_diag_p->flow_id     = (data_4b >> 16) & 0xFFFF;
    tp_diag_p->flow_tp_idx = (data_4b >>  0) & 0xFFFF;

    // vir_addr
    data_4b = ntohl(tp_p[45]);
    tp_diag_p->vir_addr    = data_4b;

    // magic
    data_4b = ntohl(tp_p[46]);
    tp_diag_p->magic       = data_4b;
}


