#ifndef _NG_VIDEO_DIAG_H_
#define _NG_VIDEO_DIAG_H_



#define VIDEO_DIAG_MAGIC                0xDEADBEEF

#define VIDEO_DIAG_ERR_PID              0x01
#define VIDEO_DIAG_ERR_CC               0x02
#define VIDEO_DIAG_ERR_OUT_TIME         0x04
#define VIDEO_DIAG_ERR_HEADER           0x08
#define VIDEO_DIAG_ERR_PCR_FLAG         0x10






// TP header
//
typedef struct tp_header_ {
    uint32_t sync : 8;
    uint32_t transport_err : 1;
    uint32_t payload_unit_start : 1;
    uint32_t priority : 1;
    uint32_t pid : 13;
    uint32_t scrambling_ctrl : 2;
    uint32_t af_ctrl : 2;
    uint32_t cc : 4;
} tp_header_t;


// Adaptation field definition (for PCR processing)
//
typedef struct af_header_ {
    uint8_t len;

    uint8_t discontinuity : 1;
    uint8_t random_access : 1;
    uint8_t es_priority : 1;
    uint8_t pcr_flag : 1;
    uint8_t opcr_flag : 1;
    uint8_t splice_point : 1;
    uint8_t private_data : 1;
    uint8_t af_ext : 1;

    uint16_t pcr_base_1;

    uint16_t pcr_base_2;

    uint16_t pcr_base_3 : 1;
    uint16_t resv : 6;
    uint16_t pcr_ext : 9;
} af_header_t;


// TP info
//
typedef struct tp_info_ {
    // Word 1
    uint32_t info_type   : 2;     // should be TP_INFO
    uint32_t pcr_flag    : 1;     // set if the TP carries PCR
    uint32_t disc_flag   : 1;     // discontinuity flag
    uint32_t pat_flag    : 1;     // set if this TP carries PAT
    uint32_t pmt_flag    : 1;     // set if this TP carries PMT
    uint32_t idle_flag   : 1;     // set in 1st TP after session resume from idle
    uint32_t unused_flag : 1;     // unused flag

    uint32_t usage_id    : 4;     // for TP Info array overrun detection
    uint32_t arvl_time   : 20;    // arrival time in 45 kHz ticks

    // Word 2
    uint16_t tp_idx;              // TP index
    uint16_t pid_idx;             // index of PID in input/output pid table
                                  // Note: for passthru sessions, this field is
                                  //       only set for PSI TPs

    // Word 3 (or 3-4 for 64-bit system)
    uintptr_t addr;               // TP address (physical)
} tp_info_t;


// PCR info
//
typedef struct {
    // Word 1
    uint32_t info_type   : 2;     // should be PCR_INFO
    uint32_t out_time    : 20;    // out time (in 45 kHz ticks)
                                  // (least significant 20 bits)
    uint32_t tbo_ext     : 10;    // time base offset - 27 MHz ext part

    // Word 2
    uint32_t tbo_base;            // time base offset - 45 kHz base part (32 bit)

    // Word 3
    uint32_t valid_flag  : 1;     // whether tp_itvl has been updated
                                  // with next PCR value.
    uint32_t tp_itvl     : 31;    // TP interval - 45 kHz clock ticks in F10.20
                                  // Note: For debugging, we store PID here
                                  //       for slave PCR
} pcr_info_t;


// JIB output command
typedef struct jib_command_ {
    // Word 1
    uint32_t qam_id           : 11;       // QAM channel ID
    uint32_t res1             : 9;        // reserved bit
    uint32_t pkt_type         : 5;        // packet type (2 for video)
    uint32_t res2             : 3;        // reserved bit
    uint32_t cwi_hi           : 4;        // code word index [15:12]

    // Word 2
    uint32_t cwi_lo           : 12;       // code word index [11:0]
    uint32_t out_time         : 20;       // delivery time

    // Word 3
    uint32_t pid_restamp_flag : 1;        // PID restamp flag
    uint32_t cc_restamp_flag  : 1;        // CC restamp flag
    uint32_t pcr_restamp_flag : 1;        // PCR restamp flag
    uint32_t disc_flag        : 1;        // discontinuity set flag
    uint32_t resv3            : 1;        // reserved
    uint32_t cc               : 4;        // CC restamp value
    uint32_t pid              : 13;       // PID restamp value
    uint32_t tbo_ext          : 10;       // time base offset - extension part

    // Word 4
    uint32_t tbo_base;                    // time base offset - base part
} jib_command_t;


typedef struct tp_diag_ {
    tp_header_t   tp_hdr;         //  0
    af_header_t   af_hdr;         //  1
    uint32_t      gap[26];        //  3
    uint32_t      time;           // 29    NEW
    tp_header_t   orig_tp_hdr;    // 30    copy of the original TP header, with the sync byte inversed
    af_header_t   orig_af_hdr;    // 31    copy of the original potential AF header
    tp_info_t     tp_info;        // 33    TP info
    pcr_info_t    pcr_info;       // 37    PCR info (for master PCR only)
    jib_command_t jib_cmd;        // 40    copy of the output command       // _YWL_PCR_DEBUG_  <<<<
    uint16_t      flow_id;        // 44    Flow ID
    uint16_t      flow_tp_idx;    // 44.5  TP index within its flow
    uint32_t      vir_addr;       // 45    virtual address of TP buffer
    uint32_t      magic;          // 46    magic number VIDEO_DIAG_MAGIC
} __attribute__((packed)) tp_diag_t;



void chck_tp_diag_t_size(void);
void tp_2_tp_diag(uint32_t *tp_p, tp_diag_t *tp_diag_p);

void tp_hex_dump_tp_diag(tp_diag_t *tp_diag_p);

void tp_hex_dump_tp_head_t (tp_header_t *tp_header_p);
void tp_hex_dump_af_head_t (af_header_t *af_header_p);
void tp_hex_dump_tp_info_t(tp_info_t *tp_info_p);
void tp_hex_dump_pcr_info_t(pcr_info_t *pcr_info_p);
void tp_hex_dump_jib_command_t(jib_command_t *jib_cmd_p);
void tp_hex_dum_misc(tp_diag_t *tp_diag_p);

void tp_hex_dump_jib_command_t_tbo(jib_command_t *jib_cmd_p);
void tp_dec_dump_jib_command_t_tbo(jib_command_t *jib_cmd_p);




#endif // _NG_VIDEO_DIAG_H_

